for one in range(10-1):
    for two in range(one+1, 10):
        print(one, two)